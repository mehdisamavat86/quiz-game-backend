using RandomQuestionApi.Logics;
using RandomQuestionApi.ViewModels;

namespace RandomQuestionApiTest
{

    public class QuestionFactoryTest
    {
        [Fact]
        public void Generate_Random_Questions()
        {
            var loader = new QuestionLoader();
            var questionFactory = new QuestionFactory(loader);

            var res = questionFactory.GenerateQuestions(5);
            Assert.NotNull(res);
            Assert.Empty(res.ErrorMessage);
            Assert.Equal(5, res.Questions.Count);

            res = questionFactory.GenerateQuestions(1);
            Assert.NotNull(res);
            Assert.Empty(res.ErrorMessage);
            Assert.Equal(1, res.Questions.Count);

            res = questionFactory.GenerateQuestions(9);
            Assert.NotNull(res);
            Assert.NotEmpty(res.ErrorMessage);
            Assert.Contains("are more than existing questions", res.ErrorMessage);

            res = questionFactory.GenerateQuestions(0);
            Assert.NotNull(res);
            Assert.NotEmpty(res.ErrorMessage);
            Assert.Contains("can not be equal or less than 0", res.ErrorMessage);
        }

        [Fact]
        public void Submit_User_Answers()
        {
            var loader = new QuestionLoader();
            var questionFactory = new QuestionFactory(loader);

            var userAnswers = new UserAnswerViewModel
            {
                Answers = new List<UserAnswerModel>
                {
                    { new UserAnswerModel { QuestionId = "a99907e3-ee17-4ac3-89be-ae08c4f699d5", AnswerId = "1"  } },
                    { new UserAnswerModel { QuestionId = "01fe569c-bb6a-4586-97b3-59d15b63c132", AnswerId = "2"  } },
                    { new UserAnswerModel { QuestionId = "9f56e35b-5de0-498d-8da5-46d0bb2c925e", AnswerId = "2"  } }
                }
            };

            var res = questionFactory.CheckAnswers(userAnswers.Answers);
            Assert.NotNull(res);
            Assert.Empty(res.ErrorMessage);
            Assert.Equal(userAnswers.Answers.Count, res.Results.Count);
            Assert.Equal(2, res.Results.Count(_ => !_.WasCorrect));
            Assert.Equal(1, res.Results.Count(_ => _.WasCorrect));
            Assert.Equal(2, res.Results.Count(_ => _.UserAnswer != _.CorrectAnswer));
        }
    }
}
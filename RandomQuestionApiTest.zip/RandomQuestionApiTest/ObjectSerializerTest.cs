using RandomQuestionApi.Logics;

namespace RandomQuestionApiTest
{

    public class Serializer : ObjectSerializer
    {

    }

    public class TestModel
    {
        public int Id { get; set; }
        public string Name { get; set; } = "";
        public bool Flag { get; set; }

    }
    public class ObjectSerializerTest
    {
        [Fact]
        public void Serilized_Deserialiozed()
        {
            var model = new TestModel { Id = 1, Flag = true, Name = "Random Game Test" };
            var serializer = new Serializer();
            var res = serializer.Serialize(model);
            Assert.NotNull(res);
            Assert.NotEmpty(res);

            var desModel = serializer.Deserialize<TestModel>(res);
            Assert.NotNull(desModel);

            Assert.Equal(desModel?.GetType(), model.GetType());  
            Assert.Equal(desModel?.Id, model.Id);
            Assert.Equal(desModel?.Name, model.Name);
            Assert.Equal(desModel?.Flag, model.Flag);
        }
    }
}
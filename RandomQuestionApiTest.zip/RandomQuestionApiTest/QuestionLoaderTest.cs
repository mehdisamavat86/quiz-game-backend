using RandomQuestionApi.Logics;

namespace RandomQuestionApiTest
{

    public class QuestionLoaderTest
    {
        [Fact]
        public void Load_Questions()
        {
            var loader = new QuestionLoader();
            var res = loader.Load();
            Assert.NotNull(res);
            Assert.NotEqual(0, res.Count);
            Assert.Equal(8, res.Count);

        }
    }
}
﻿namespace RandomQuestionApi.ViewModels
{
    public class ErrorViewModel
    {
        public string ErrorMessage { get; set; } = "";
    }
}

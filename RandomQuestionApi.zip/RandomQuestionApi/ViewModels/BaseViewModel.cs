﻿namespace RandomQuestionApi.ViewModels
{
    public class BaseViewModel : ErrorViewModel
    {

    }
}
